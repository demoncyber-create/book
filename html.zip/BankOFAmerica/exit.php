<?php
header("location:https://www.bankofamerica.com/");
?>